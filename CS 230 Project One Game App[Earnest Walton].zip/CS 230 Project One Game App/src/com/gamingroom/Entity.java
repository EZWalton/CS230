package com.gamingroom;

/**
 * Base entity class containing the common identifier and name used by
 * games, teams, and players.
 *
 * @author coce@snhu.edu
 */
public class Entity {

    private long id;
    private String name;

    /**
     * Hide the default constructor to prevent empty entities.
     */
    private Entity() {
    }

    /**
     * Constructor with an identifier and name.
     *
     * @param id unique identifier for the entity
     * @param name name of the entity
     */
    public Entity(long id, String name) {
        this();
        this.id = id;
        this.name = name;
    }

    /**
     * @return the id
     */
    public long getId() {
        return id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Entity [id=" + id + ", name=" + name + "]";
    }
}
