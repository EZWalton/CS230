package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A singleton service for the game engine.
 *
 * @author coce@snhu.edu
 */
public class GameService {

    /**
     * A list of the active games.
     */
    private static List<Game> games = new ArrayList<Game>();

    /**
     * Holds the next identifiers for games, players, and teams.
     */
    private static long nextGameId = 1;
    private static long nextPlayerId = 1;
    private static long nextTeamId = 1;

    /**
     * Holds the single instance of GameService.
     */
    private static GameService service = null;

    /**
     * Private constructor prevents other classes from creating
     * additional instances of GameService.
     */
    private GameService() {
    }

    /**
     * Provides global access to the single GameService instance.
     *
     * @return the single GameService instance
     */
    public static GameService getInstance() {
        if (service == null) {
            service = new GameService();
        }

        return service;
    }

    /**
     * Constructs a new game instance if the name is not already in use.
     *
     * @param name the unique name of the game
     * @return the game instance, either new or existing
     */
    public Game addGame(String name) {
        Game game = getGame(name);

        if (game == null) {
            game = new Game(nextGameId++, name);
            games.add(game);
        }

        return game;
    }

    /**
     * Returns the game instance at the specified index.
     *
     * @param index index position in the list to return
     * @return requested game instance
     */
    Game getGame(int index) {
        return games.get(index);
    }

    /**
     * Returns the game instance with the specified id.
     *
     * @param id unique identifier of the game to search for
     * @return requested game instance, or null if not found
     */
    public Game getGame(long id) {
        Game game = null;
        Iterator<Game> iterator = games.iterator();

        while (iterator.hasNext()) {
            Game currentGame = iterator.next();
            if (currentGame.getId() == id) {
                game = currentGame;
                break;
            }
        }

        return game;
    }

    /**
     * Returns the game instance with the specified name.
     *
     * @param name unique name of the game to search for
     * @return requested game instance, or null if not found
     */
    public Game getGame(String name) {
        Game game = null;
        Iterator<Game> iterator = games.iterator();

        while (iterator.hasNext()) {
            Game currentGame = iterator.next();
            if (currentGame.getName().equals(name)) {
                game = currentGame;
                break;
            }
        }

        return game;
    }

    /**
     * @return the number of games currently active
     */
    public int getGameCount() {
        return games.size();
    }

    /**
     * Returns the next unique player identifier and advances the counter.
     *
     * @return the next unique player id
     */
    public long getNextPlayerId() {
        return nextPlayerId++;
    }

    /**
     * Returns the next unique team identifier and advances the counter.
     *
     * @return the next unique team id
     */
    public long getNextTeamId() {
        return nextTeamId++;
    }
}
