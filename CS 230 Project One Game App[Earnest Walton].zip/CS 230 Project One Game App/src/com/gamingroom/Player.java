package com.gamingroom;

/**
 * A player entity.
 *
 * @author coce@snhu.edu
 */
public class Player extends Entity {

    /**
     * Constructor with an identifier and name.
     *
     * @param id unique identifier for the player
     * @param name unique name of the player
     */
    public Player(long id, String name) {
        super(id, name);
    }

    @Override
    public String toString() {
        return "Player [id=" + getId() + ", name=" + getName() + "]";
    }
}
