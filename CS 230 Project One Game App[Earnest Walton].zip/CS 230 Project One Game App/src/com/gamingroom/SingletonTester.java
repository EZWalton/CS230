package com.gamingroom;

/**
 * A class to test a singleton's behavior
 *
 * @author coce@snhu.edu
 */
public class SingletonTester {

    public void testSingleton() {

        System.out.println("\nAbout to test the singleton...");

        // Obtain a local reference to the one-and-only singleton instance.
        // Calling getInstance() returns the same GameService object
        // that was previously used by ProgramDriver.
        GameService service = GameService.getInstance();

        // A simple for loop to print the games.
        // If the singleton is working correctly, this instance will
        // contain the same games that were added in ProgramDriver.
        for (int i = 0; i < service.getGameCount(); i++) {
            System.out.println(service.getGame(i));
        }
    }
}