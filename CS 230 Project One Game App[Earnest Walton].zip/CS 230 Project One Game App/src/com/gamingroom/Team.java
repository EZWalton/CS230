package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A team entity that contains a collection of players.
 *
 * @author coce@snhu.edu
 */
public class Team extends Entity {

    private List<Player> players = new ArrayList<Player>();

    /**
     * Constructor with an identifier and name.
     *
     * @param id unique identifier for the team
     * @param name unique name of the team
     */
    public Team(long id, String name) {
        super(id, name);
    }

    /**
     * Adds a player to the team if a player with the same name does not
     * already exist. If the player already exists, that player is returned.
     *
     * @param name unique player name within this team
     * @return the new or existing player
     */
    public Player addPlayer(String name) {
        Player player = null;

        Iterator<Player> iterator = players.iterator();
        while (iterator.hasNext()) {
            Player currentPlayer = iterator.next();
            if (currentPlayer.getName().equals(name)) {
                player = currentPlayer;
                break;
            }
        }

        if (player == null) {
            player = new Player(GameService.getInstance().getNextPlayerId(), name);
            players.add(player);
        }

        return player;
    }

    @Override
    public String toString() {
        return "Team [id=" + getId() + ", name=" + getName() + "]";
    }
}
