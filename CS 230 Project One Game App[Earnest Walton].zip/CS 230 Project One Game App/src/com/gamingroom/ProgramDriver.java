package com.gamingroom;

/**
 * Application start-up program.
 *
 * @author coce@snhu.edu
 */
public class ProgramDriver {

    /**
     * The one-and-only main() method.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {

        GameService service = GameService.getInstance();

        System.out.println("\nAbout to test initializing game data...");

        Game game1 = service.addGame("Game #1");
        Game game2 = service.addGame("Game #2");

        System.out.println(game1);
        System.out.println(game2);

        // Verify that duplicate game names return the existing game.
        Game duplicateGame = service.addGame("Game #1");
        System.out.println("Duplicate game returns existing instance: " + (game1 == duplicateGame));

        // Add teams and demonstrate duplicate-name protection within a game.
        Team redTeam = game1.addTeam("Red Team");
        Team blueTeam = game1.addTeam("Blue Team");
        Team duplicateTeam = game1.addTeam("Red Team");

        System.out.println(redTeam);
        System.out.println(blueTeam);
        System.out.println("Duplicate team returns existing instance: " + (redTeam == duplicateTeam));

        // Add players and demonstrate duplicate-name protection within a team.
        Player player1 = redTeam.addPlayer("Player One");
        Player player2 = redTeam.addPlayer("Player Two");
        Player duplicatePlayer = redTeam.addPlayer("Player One");

        System.out.println(player1);
        System.out.println(player2);
        System.out.println("Duplicate player returns existing instance: " + (player1 == duplicatePlayer));

        // Use another class to prove there is only one GameService instance.
        SingletonTester tester = new SingletonTester();
        tester.testSingleton();
    }
}
