package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A game entity that contains a collection of teams.
 *
 * @author coce@snhu.edu
 */
public class Game extends Entity {

    private List<Team> teams = new ArrayList<Team>();

    /**
     * Constructor with an identifier and name.
     *
     * @param id unique identifier for the game
     * @param name unique name of the game
     */
    public Game(long id, String name) {
        super(id, name);
    }

    /**
     * Adds a team to the game if a team with the same name does not
     * already exist. If it does exist, the existing team is returned.
     *
     * @param name unique team name within this game
     * @return the new or existing team
     */
    public Team addTeam(String name) {
        Team team = null;

        Iterator<Team> iterator = teams.iterator();
        while (iterator.hasNext()) {
            Team currentTeam = iterator.next();
            if (currentTeam.getName().equals(name)) {
                team = currentTeam;
                break;
            }
        }

        if (team == null) {
            team = new Team(GameService.getInstance().getNextTeamId(), name);
            teams.add(team);
        }

        return team;
    }

    @Override
    public String toString() {
        return "Game [id=" + getId() + ", name=" + getName() + "]";
    }
}
